class Task{
    constructor(priority, title, desc, dueDate, status, category, color){
        this.priority =priority;
        this.title =title;
        this.description =desc;
        this.dueDate =dueDate;
        this.status =status;
        this.category =category;
        this.color = color;
    }
}