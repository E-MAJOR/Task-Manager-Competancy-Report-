var important=false;
var icon;
var formVisible=true;
function togglePriority(){
    console.log("clicked1");
    if(important){
        //set non-important
        // $("#iPriority").removeClass("fas");
        // $("#iPriority").addClass("far");
        important=false;
        var formVisible=true;
        icon.removeClass("fas");
        icon.addClass("far");
    } else {
        //set important
        // $("#iPriority").removeClass("far");
        // $("#iPriority").addClass("fas");
        // icon.removeClass("far"); // after defining icon
        // icon.addClass("fas");
        icon.removeClass("far").addClass("fas");
        important=true;
    }
}

function toggleForm(){
    if(formVisible){
        $(".section-form").hide();
        formVisible=false;
    } else {
        $(".section-form").show();
        formVisible=true;
    }
}

function saveTask(){
    console.log("saving task");
    let title = $("#txtTitle").val();
    let desc=$("#txtDescription").val();
    let dueDate=$("#dpDueDate").val();
    let status=$("#selStatus").val();
    let color=$("#selColor").val();
    let category=$("#selCategory").val();
    let theTask= new Task(important, title, desc, dueDate, status, category, color);
    console.log(theTask);
    displayTask(theTask);
    clearForm();
}

function clearForm(){
    $("#txtTitle").val("");
    $("#txtDescription").val("");
    $("#dpDueDate").val("");
    $("#selStatus").val("");
    $("#selColor").val("");
    $("#selCategory").val("");
}

function displayTask(task){
    let syntax = `<div class="task">
        <i class="far fa-star"></i>

        <div class="info">
            <h5>${task.title}</h5>
            <p>${task.description}</p>
        </div>

        <div class="details">
            <label class="status">${task.status}</label>
            <label class="category">${task.category}</label>
        </div>
    </div>`;

    $(".task-list").append(syntax);
}
function init(){
    console.log("task manager");
    icon=$("#iPriority");
    //hook or assign events jQuery
            // $("#iPriority").click(togglePriority);
    icon.click(togglePriority);
    $("#btnShowDetails").click(toggleForm);
    $("#btnSave").click(saveTask);
    //load data
}

window.onload=init;