//Object Literal
let dog={
    name:"fido",
    age:3,
    color:"red"
};
console.log(dog);

let cat={
    name:"Smokey",
    age:5,
    color:"black"
};
console.log(cat);

//object constructor
function Pet(name, age, color){
    this.name=name;
    this.age=age;
    this.color=color;
}

let lion= new Pet("Alex", 6, "Yellow");
console.log(lion);

let zebra= new Pet("Zerena", 12, "Black/White");
console.log(lion);
console.log(zebra);

// class
class Animal{
    // exec auto when new object created
    constructor(name, age){
        this.name=name;
        this.age=age;
    }
    doSomething(){
        console.log("do something");
    }
}
let wildcat= new Animal("Will", 3);
console.log(wildcat);